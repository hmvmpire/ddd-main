



const WrapperImage = (props) =>{



    return <>
        <div className="wrapperImage__main">
            {props.children}
        </div>

    </>
}

export default WrapperImage;