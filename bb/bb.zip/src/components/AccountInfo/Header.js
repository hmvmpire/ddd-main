import logo from '../../assets/bcmlogo.png';

const Header = (props) => {
  return (
    <>
      <header>
        <img alt='bcmlogo' src={logo} />
      </header>
    </>
  );
};

export default Header;
