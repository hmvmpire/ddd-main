const Home = (props) => {
  return (
    <>
      <h1>haha</h1>
    </>
  );
};

export default Home;
