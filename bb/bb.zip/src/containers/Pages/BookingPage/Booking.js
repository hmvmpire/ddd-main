import React from 'react';
import Room from '../../../components/Room/RoomD/Room.js';
const Booking = (props) => {
  return (
    <>
      <Room />
    </>
  );
};

export default Booking;
