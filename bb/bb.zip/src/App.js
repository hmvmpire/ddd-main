import './style/main.scss';
import AppRouter from './containers/Router';

function App() {
  return <AppRouter />;
}

export default App;
